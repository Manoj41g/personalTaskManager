import React from "react";
import ReactDOM from "react-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import "./styles.css";
import Board from "./react/components/taskManagement/Board.jsx";

function App(){
    return(
        <div>
            <Board />
        </div>
    );
}

ReactDOM.render(<App />, document.getElementById("root"));