import React, { Component } from "react";
import List from "./List.jsx";
import Card from "./Card.jsx"
class Board extends Component{
    constructor(props){
        super(props);
        this.state = {
            lists: [],
            incrementer: 0,
        };
    }
    onAddNewListHandler = () => {
        this.setState((prevState) => {
            return {
                lists: [...prevState.lists, 
                        {   id: prevState.incrementer + 1, 
                            name: "List",
                            cards: [],
                            cardIncrementer: 0
                        }
                ],
                incrementer: prevState.incrementer + 1
            };
        });
    }
    onDeleteListHandler = (event, id) => {
        let lists = [...this.state.lists];
        let updatedLists = lists.filter((item) => (item.id !== id));
        this.setState({lists: [...updatedLists]});
    }
    onAddNewCardHandler = (event, listId) => {
        this.setState((prevState) => {
            let lists = [...prevState.lists];
            let cardIncrementer = 0;
            for (let listItem of lists) {
                if(listItem.id === listId){
                    if(listItem.cards.length !== 0){
                        listItem["cards"] = [...listItem.cards];
                        cardIncrementer = listItem.cardIncrementer;
                    }
                    
                    listItem["cards"].push( { cardId: cardIncrementer + 1, 
                        name: "Card Title"
                    });
                    listItem.cardIncrementer = cardIncrementer + 1;
                    break;
                }
             }

            return {
                lists
            };
        });
    }
    onDeleteCardHandler = (event, cardId, listId) => {
        let lists = [...this.state.lists];
        let updatedCards;
        for (let listItem of lists) {
            if(listItem.id === listId){
                updatedCards = listItem.cards.filter((cardItem) => (cardItem.cardId !== cardId));
                listItem.cards = updatedCards;
                break;
            }
         }
         
         this.setState({lists: [...lists]});
     }

     renderPage = () => {
         return (this.state.lists.map((item) => { return (
                    <List key={item.id} 
                        name={item.name}
                        onDeleteListHandler={this.onDeleteListHandler} 
                        onAddNewCardHandler={this.onAddNewCardHandler}
                        id={item.id}
                    >
                        {item.cards.map((cardItem) => {
                            return (<Card 
                                        cardId={cardItem.cardId}
                                        key={cardItem.cardId} 
                                        listId={item.id} 
                                        onDeleteCardHandler={this.onDeleteCardHandler}
                                    />)
                        })}
                    </List>
                )}));
     }
     allowListDrop = (event) => {
        event.preventDefault();
    }
    listDrop = (event) => {
        event.preventDefault();
        var draggedListId = event.dataTransfer.getData("draggedList");
        if(event.target.className === "list" && draggedListId){
            event.target.parentElement.after(document.getElementById(draggedListId));
        }
    }
    render(){
        return(
                <div className={"container"}>
                    <div className={"row"}>
                        <h2>Board</h2>
                    </div>
                    <div className={"row"}>
                        <div className={"col-sm-10"}>
                            <div className={"row"} onDrop={this.listDrop} onDragOver={this.allowListDrop}>
                                {this.renderPage()}
                            </div>
                        </div>
                        <div className={"col-sm-2 add-list"}>
                            <button className={"btn btn-primary float-right"}onClick={this.onAddNewListHandler}>Add new list</button>
                        </div>
                    </div>
                </div>
        );
    }
}

export default Board;