import React, { Component } from "react";
import PropTypes from 'prop-types';

class List extends Component{
    constructor(props){
        super(props);
        this.onClickDeleteListHandler = this.onClickDeleteListHandler.bind(this);
        this.onClickAddNewCardHandler = this.onClickAddNewCardHandler.bind(this);
    }
    onClickDeleteListHandler(event){
        event.preventDefault();
        this.props.onDeleteListHandler(event, this.props.id);
    }
    onClickAddNewCardHandler(event){
        event.preventDefault();
        this.props.onAddNewCardHandler(event, this.props.id);
    }
    allowDrop = (event) => {
        event.preventDefault();
    }
    drop = (event) => {
        event.preventDefault();
        var draggedCardId = event.dataTransfer.getData("draggedCard");
        if(draggedCardId && event.target.classList[1] === "card-thumbnail"){
            event.target.after(document.getElementById(draggedCardId));
        }
    }
    onListDragStart = (event) => {
        if(event.target.classList[1] === "card-thumbnail"){
            return;
        } else{
            event.dataTransfer.setData("draggedList", event.target.id);
        }
    }
    render(){
        return(
            <div id={"list"+this.props.id} className={"col-sm-4 list-container h-100"} onDrop={this.drop} onDragOver={this.allowDrop} draggable="true" onDragStart={(event) => this.onListDragStart(event)}>
                <div className={"list"}  >
                    <span className={"list-name"}>{this.props.name} - {this.props.id}</span>
                    <span className={"float-right"}>
                        <a href="" onClick={this.onClickDeleteListHandler}>Delete this list</a>
                    </span>
                    {this.props.children}
                    <div className={"add-card"}>
                        <a href="" onClick={this.onClickAddNewCardHandler}>Add new card</a>
                    </div>
                </div>
            </div>
        );
    }
}

List.propTypes = {
    onDeleteListHandler: PropTypes.func,
    id: PropTypes.number,
    onAddNewCardHandler: PropTypes.func,
    name: PropTypes.string,
    children: PropTypes.array

}

export default List;