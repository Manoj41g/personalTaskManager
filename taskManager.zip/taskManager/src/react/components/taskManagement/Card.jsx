import React, {Component} from "react";
import PropTypes from 'prop-types';

class Card extends Component{
    constructor(props){
        super(props);
        this.state = {
            enterCardDetails: true,
            title: "",
            description: "",
            comments: [],
            newComment: "",
            commentsCount: 0
        }
    }
    onChangeHandler = (event) => {
        this.setState({
            [event.target.name]: event.target.value
        });
    }
    onSubmitHandler = (event) => {
        event.preventDefault();
        this.setState({
            enterCardDetails: false
        });
    }
    onEditCardHandler = (event) => {
        event.preventDefault();
        this.setState({
            enterCardDetails: true
        });
    }
    addCommentHandler = () => {
        if(this.state.newComment === ""){
            return;
        }

        let currentDate = new Date().toLocaleDateString();
        this.setState((prevState) => {
            return {
                comments: [...prevState.comments, {comment: prevState.newComment, date: currentDate, id: prevState.commentsCount + 1 }],
                newComment: "",
                commentsCount: prevState.commentsCount + 1
            };
        });
    }
    deleteCardHandler = (event) => {
        this.props.onDeleteCardHandler(event, this.props.cardId, this.props.listId);
    }
    onDragStart = (event) => {
        event.dataTransfer.setData("draggedCard", event.target.id);
    }
    renderCard = () => {
        let cardNode;
        if(this.state.enterCardDetails){
            cardNode = (
            <div className={"card-form"}>
                <form onSubmit={this.onSubmitHandler}>
                    <input type="text" name={"title"} autoFocus className={"form-control"} placeholder={"Card title"} required value={this.state.title} onChange={this.onChangeHandler} />
                    <textarea name={"description"} className={"form-control"} placeholder={"Card description"} value={this.state.description} onChange={this.onChangeHandler} />
                    <textarea name={"newComment"} className={"form-control"} placeholder={"Comment"} value={this.state.newComment} onChange={this.onChangeHandler} />
                    <button type="button" className={"form-control btn btn-secondary"} onClick={this.addCommentHandler}>Add Comment</button>
                    <ul className={"comments-list"}>
                        {this.state.comments.map((item, index) => {
                            return (<li key={index}>
                                <div>
                                    <span className="">{item.comment}</span>
                                    <span className="float-right">{item.date}</span>
                                </div>
                            </li>)
                        })}
                    </ul>
                    <div>
                        <button className={"btn btn-success"} type="submit">Save</button>
                        <button className={"btn btn-danger float-right"} type="button" onClick={this.deleteCardHandler}>Delete Card</button>
                    </div>
                </form>
            </div>
                    
                  
                    );
        } else{
            cardNode = (<div id={"card_" + this.props.cardId + "_" + this.props.listId} className={"jumbotron card-thumbnail draggable "} data-listid={"list" + this.props.listId} draggable="true" onDragStart={(event) => this.onDragStart(event)}>
                            {this.state.title} <span className="float-right"><a href="#" onClick={this.onEditCardHandler}>Edit</a></span>
                        </div>);
        }

        return cardNode;
    }
    render(){
        return(
            <>
                {this.renderCard()}
            </>
        );
    }
}

Card.propTypes = {
    onDeleteCardHandler: PropTypes.func,
    cardId: PropTypes.number,
    listId: PropTypes.number

}

export default Card;